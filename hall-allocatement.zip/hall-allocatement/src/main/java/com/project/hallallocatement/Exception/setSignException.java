package com.project.hallallocatement.Exception;

public class setSignException extends Exception{
	
	public setSignException(String msg)
	{
		super(msg);
	}

}
