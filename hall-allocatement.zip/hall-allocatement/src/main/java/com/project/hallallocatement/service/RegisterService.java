package com.project.hallallocatement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.project.hallallocatement.Exception.ExistException;
import com.project.hallallocatement.entity.Register;
import com.project.hallallocatement.repository.RegisterRepository;

@Service
@Transactional
public class RegisterService {

    @Autowired
    private RegisterRepository registerRepository;
    private String staffid;

    public String bookHall(Register register) throws ExistException {
        String availabilityMessage = isHallAvailable(register.getblock(), register.getroom(), register.getcheckInDate(), register.getcheckOutDate(),register.getcheckInTime(),register.getcheckOutTime());
        if (availabilityMessage != null) {
            throw new ExistException(availabilityMessage);
        }
        register.setstaffid(staffid);
        registerRepository.save(register);
        return "Hall booked successfully";
    }

    private String isHallAvailable(String block, String room, String checkInDate, String checkOutDate, String checkInTime, String checkOutTime) {
        List<Register> existingBookings = registerRepository.findBookingsByBlockAndRoomAndCheckInDateLessThanEqualAndCheckOutDateGreaterThanEqualAndCheckInTimeLessThanEqualAndCheckOutTimeGreaterThanEqual(
                block, room, checkOutDate, checkInDate, checkOutTime, checkInTime);

        if (!existingBookings.isEmpty()) {
            return "Hall already booked for the specified date and time range";
        }

        return null; // Hall is available
    }
}
