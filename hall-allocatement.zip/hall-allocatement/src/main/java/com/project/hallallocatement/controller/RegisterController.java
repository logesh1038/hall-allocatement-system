package com.project.hallallocatement.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.project.hallallocatement.Exception.ExistException;
import com.project.hallallocatement.entity.Register;
import com.project.hallallocatement.service.RegisterService;

@CrossOrigin(origins = "http://127.0.0.1:5500")
@RestController
public class RegisterController {

    @Autowired
    private RegisterService registerService;

    @PostMapping("/register/book-hall")
    public String bookHall(@RequestBody Register register) {
        try {
            return registerService.bookHall(register);
        } catch (ExistException e) {
            return e.getMessage();
        }
    }
}
