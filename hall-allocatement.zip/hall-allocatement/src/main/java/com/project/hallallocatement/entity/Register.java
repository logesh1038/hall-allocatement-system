package com.project.hallallocatement.entity;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "register")
public class Register {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String block;
    private String room;
    private String department;
    private String checkInDate;
    private String checkOutDate;
    private String checkInTime;
    private String checkOutTime;
    private int numberOfSeats;
    private String staffid; 

	public int getid(){
		return id;
	}
		public void setid(int id){
			this.id=id;
		}
	public String getblock() {
		return block;
	}
	public void setblock(String block) {
		this.block = block;
	}
	public String getroom() {
		return room;
	}
	public void setroom(String room) {
		this.room = room;
	}

    public String getdepartment() {
		return department;
	}
	public void setdepartment(String department) {
		this.department = department;
	}
    public String getcheckInDate(){
        return checkInDate;
    }
    public void setcheckInDate(String checkInDate){
        this.checkInDate=checkInDate;
    }

    public String getcheckOutDate(){
        return checkOutDate;
    }
	public void setcheckOutDate(String checkOutDate){
        this.checkOutDate=checkOutDate;
    }
    public String getcheckInTime(){
        return checkInTime;
    }
    public void setcheckInTime(String checkInTime){
        this.checkInTime=checkInTime;
    }
    public String getcheckOutTime(){
        return checkOutTime;
    }
    public void setcheckOutTime(String checkOutTime){
        this.checkOutTime=checkOutTime;
    }
    public int getnumberOfSeats(){
        return numberOfSeats;
    }
    public void setnumberOfSeats(int numberOfSeats){
        this.numberOfSeats=numberOfSeats;
    }

    public String getstaffid() {
		return staffid;
	}
	public void setstaffid(String staffid) {
		this.staffid = staffid;
	}
	
}
