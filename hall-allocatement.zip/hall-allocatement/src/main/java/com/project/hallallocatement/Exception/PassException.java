package com.project.hallallocatement.Exception;

public class PassException extends Exception{
	
	public PassException(String msg)
	{
		super(msg);
	}
	

}
