package com.project.hallallocatement.Exception;


public class MailException extends Exception{
	
	public  MailException(String msg)
	{
		super(msg);
	}

}
