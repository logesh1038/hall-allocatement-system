package com.project.hallallocatement.dao;

public class RegisterDao {
    
}
