package com.project.hallallocatement.Exception;

public class ExistException extends Exception{
	
	public ExistException(String msg)
	{
		super(msg);
	}

}
