package com.project.hallallocatement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HallAllocatementApplicationTests {

	@Test
	void contextLoads() {
	}

}
